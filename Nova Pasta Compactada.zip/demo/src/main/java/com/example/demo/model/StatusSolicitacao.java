package com.example.demo.model;

public enum StatusSolicitacao {
    ABERTO,
    EM_ANDAMENTO,
    CONCLUIDO
}
