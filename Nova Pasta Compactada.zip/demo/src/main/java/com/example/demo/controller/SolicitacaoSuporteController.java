package com.example.demo.controller;

import com.example.demo.model.SolicitacaoSuporte;
import com.example.demo.service.SolicitacaoSuporteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/solicitacoes")
public class SolicitacaoSuporteController {

    @Autowired
    private SolicitacaoSuporteService service;

    @PostMapping
    public ResponseEntity<SolicitacaoSuporte> criarSolicitacao(@RequestBody SolicitacaoSuporte solicitacao) {
        return ResponseEntity.ok(service.criarSolicitacao(solicitacao));
    }

    @GetMapping
    public ResponseEntity<List<SolicitacaoSuporte>> listarSolicitacoes() {
        return ResponseEntity.ok(service.listarSolicitacoes());
    }

    @GetMapping("/{id}")
    public ResponseEntity<SolicitacaoSuporte> buscarPorId(@PathVariable Long id) {
        return service.buscarPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<SolicitacaoSuporte> atualizarSolicitacao(@PathVariable Long id, @RequestBody SolicitacaoSuporte solicitacao) {
        return ResponseEntity.ok(service.atualizarSolicitacao(id, solicitacao));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletarSolicitacao(@PathVariable Long id) {
        service.deletarSolicitacao(id);
        return ResponseEntity.noContent().build();
    }
}
