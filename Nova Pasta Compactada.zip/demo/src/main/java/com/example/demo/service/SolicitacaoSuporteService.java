package com.example.demo.service;

import com.example.demo.model.SolicitacaoSuporte;
import com.example.demo.model.StatusSolicitacao;
import com.example.demo.repository.SolicitacaoSuporteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class SolicitacaoSuporteService {

    @Autowired
    private SolicitacaoSuporteRepository repository;

    public SolicitacaoSuporte criarSolicitacao(SolicitacaoSuporte solicitacao) {
        solicitacao.setDataAbertura(LocalDateTime.now());
        solicitacao.setStatus(StatusSolicitacao.ABERTO);
        return repository.save(solicitacao);
    }

    public List<SolicitacaoSuporte> listarSolicitacoes() {
        return repository.findAll();
    }

    public Optional<SolicitacaoSuporte> buscarPorId(Long id) {
        return repository.findById(id);
    }

    public SolicitacaoSuporte atualizarSolicitacao(Long id, SolicitacaoSuporte atualizacao) {
        return repository.findById(id).map(solicitacao -> {
            solicitacao.setStatus(atualizacao.getStatus());
            solicitacao.setDescricao(atualizacao.getDescricao());
            solicitacao.setPrioridade(atualizacao.getPrioridade());
            return repository.save(solicitacao);
        }).orElseThrow(() -> new RuntimeException("Solicitação não encontrada"));
    }

    public void deletarSolicitacao(Long id) {
        repository.deleteById(id);
    }
}
